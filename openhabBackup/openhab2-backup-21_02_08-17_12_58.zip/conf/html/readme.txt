Serve your own static html pages or resources from here.
Files stored in this folder will be available through the HTTP server of openHAB, e.g. "http://device-address:8080/static/image.png".
Resources for sitemap elements (image, video,...) can also be provided though this folder.
