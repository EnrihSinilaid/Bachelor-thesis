Your persistence configuration goes here.
All persistence files have to have the ".persist" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/persistence.html
