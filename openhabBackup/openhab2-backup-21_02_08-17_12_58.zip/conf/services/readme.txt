Your service configurations will reside here.
All configuration files have to have the ".cfg" file extension.
Service configuration files are automatically created as soon as you install an add-on that can be configured.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/services.html
